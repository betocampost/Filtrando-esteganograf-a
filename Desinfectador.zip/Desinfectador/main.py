import tkinter as tk
from tkinter import filedialog, messagebox
from tkinterdnd2 import DND_FILES, TkinterDnD
import shutil
import random
from PIL import Image
import mimetypes
import subprocess

class App:
    def __init__(self, root):
        self.root = root
        self.root.title("Aplicación de Ocultación de Texto")
        self.root.geometry("400x400")

        self.file_paths = []

        # Configurar Drag and Drop
        self.dnd_frame = tk.Frame(root, width=400, height=100, bg="lightgray")
        self.dnd_frame.pack(pady=20)
        self.dnd_frame.drop_target_register(DND_FILES)
        self.dnd_frame.dnd_bind('<<Drop>>', self.drop_files)

        self.label = tk.Label(self.dnd_frame, text="Arrastra archivos aquí o haz clic en el botón para seleccionar")
        self.label.pack(pady=20)

        # Botón para seleccionar archivos
        self.select_button = tk.Button(root, text="Seleccionar Archivos", command=self.select_files)
        self.select_button.pack(pady=10)

        # Botón para ocultar texto
        self.ocultar_button = tk.Button(root, text="Ocultar Texto", command=self.ocultar_texto)
        self.ocultar_button.pack(pady=10)

    def select_files(self):
        # Lógica para seleccionar archivos
        self.file_paths = filedialog.askopenfilenames()

        if self.file_paths:
            messagebox.showinfo("Archivos seleccionados", f"Has seleccionado {len(self.file_paths)} archivo(s).")
            print("Archivos seleccionados:", self.file_paths)

            for file in self.file_paths:
                # Verificar el tipo de archivo usando la biblioteca mimetypes
                mime_type, _ = mimetypes.guess_type(file)
                if mime_type:
                    main_type, sub_type = mime_type.split('/')
                    if main_type == 'image':
                        # Si es una imagen, usar Pillow para abrir y mostrar la imagen en una ventana nueva
                        img = Image.open(file)
                        img.show()
                    elif main_type == 'video':
                        # Si es un video, simplemente mostramos un mensaje
                        messagebox.showinfo("Archivo de Video", "El archivo seleccionado es un video.")
                    elif main_type == 'application' and sub_type == 'pdf':
                        # Si es un PDF, simplemente mostramos un mensaje
                        messagebox.showinfo("Archivo PDF", "El archivo seleccionado es un PDF.")
                    elif main_type == 'text':
                        # Si es un archivo de texto, simplemente mostramos un mensaje
                        messagebox.showinfo("Archivo de Texto", "El archivo seleccionado es un archivo de texto.")
                    else:
                        # Para cualquier otro tipo de archivo, simplemente mostramos un mensaje
                        messagebox.showinfo("Archivo No Reconocido", "El archivo seleccionado no es de un tipo reconocido.")
                else:
                    # Si no se puede determinar el tipo de archivo, simplemente mostramos un mensaje
                    messagebox.showinfo("Archivo No Reconocido", "El archivo seleccionado no es de un tipo reconocido.")

        else:
            messagebox.showwarning("Sin selección", "No se han seleccionado archivos.")

    def drop_files(self, event):
        # Lógica para manejar archivos arrastrados
        self.file_paths = self.root.tk.splitlist(event.data)
        if self.file_paths:
            messagebox.showinfo("Archivos arrastrados", f"Has arrastrado {len(self.file_paths)} archivo(s).")
            print("Archivos arrastrados:", self.file_paths)
        else:
            messagebox.showwarning("Sin selección", "No se han arrastrado archivos.")





    def ocultar_texto(self):
        if not self.file_paths:
            messagebox.showwarning("Sin archivos", "Primero selecciona o arrastra archivos.")
            return

        # Obtener el texto a ocultar
        texto_secreto = self.get_text_to_hide()

        # Seleccionar carpeta de destino
        save_directory = filedialog.askdirectory()
        if save_directory:
            for file in self.file_paths:
                palabra_aleatoria = self.bancopalabras()
                extension = file.split('.')[-1]  # Obtener la extensión del archivo original
                nuevo_nombre = f"{palabra_aleatoria}.{extension}"
                destino = f"{save_directory}/{nuevo_nombre}"
                
                # Verificar el tipo de archivo usando la biblioteca mimetypes
                mime_type, _ = mimetypes.guess_type(file)
                if mime_type:
                    main_type, sub_type = mime_type.split('/')
                    if main_type == 'image':
                        # Si es una imagen, usar Pillow para abrir y guardar
                        img = Image.open(file)
                        img.save(destino)
                    elif main_type == 'video':
                        # Si es un video, simplemente copiarlo sin modificar
                        shutil.copy(file, destino)
                    elif main_type == 'application' and sub_type == 'pdf':
                        # Si es un PDF, simplemente copiarlo sin modificar
                        shutil.copy(file, destino)
                    elif main_type == 'text':
                        # Si es un archivo de texto, simplemente copiarlo sin modificar
                        shutil.copy(file, destino)
                    else:
                        # Para cualquier otro tipo de archivo, simplemente copiarlo sin modificar
                        shutil.copy(file, destino)
                else:
                    # Si no se puede determinar el tipo de archivo, simplemente copiarlo sin modificar
                    shutil.copy(file, destino)
                
                print(f"Guardando {file} como {destino}")
            messagebox.showinfo("Descarga completa", f"Los archivos se han guardado en {save_directory}.")
        else:
            messagebox.showwarning("Sin selección", "No se ha seleccionado ninguna carpeta.")

    def get_text_to_hide(self):
        # Crear ventana para ingresar el texto secreto
        text_window = tk.Toplevel(self.root)
        text_window.title("Texto Secreto")
        
        texto_label = tk.Label(text_window, text="Ingrese el texto secreto que desea ocultar:")
        texto_label.pack()
        
        texto_entry = tk.Entry(text_window)
        texto_entry.pack()
        
        confirm_button = tk.Button(text_window, text="Confirmar", command=text_window.destroy)
        confirm_button.pack()
        
        # Esperar hasta que se cierre la ventana de texto
        text_window.wait_window()
        
        return texto_entry.get()

    def bancopalabras():
        palabras = [
            "Algoritmo", "API", "Big Data", "Blockchain", "Ciberseguridad",
            "Cloud", "Computadora", "Conectividad", "Criptomoneda", "Datos",
            "Deep Learning", "Digitalización", "Dominio", "Encriptación",
            "Firmware", "Hardware", "Hosting", "Inteligencia Artificial",
            "Internet", "IoT", "JavaScript", "Latencia", "Linux", "Máquina",
            "Microprocesador", "Móvil", "Nanotecnología", "Networking", "Nube",
            "Open Source", "Procesador", "Protocolo", "Python", "Realidad Aumentada",
            "Realidad Virtual", "Red", "Robot", "Seguridad", "Semiconductores",
            "Sensor", "Servidor", "Software", "SSD", "Streaming", "Supercomputadora",
            "Tecnología", "Telecomunicaciones", "Token", "Transistor", "USB",
            "Usuario", "Virtualización", "Usuario", "Virtualización", "VPN", "Web", "Wi-Fi", "5G", "3D", "AI",
            "Base de Datos", "Computación"
        ]
        return random.choice(palabras)

    def download_file(self):
        if not self.file_paths: 
            messagebox.showwarning("Sin archivos", "Primero selecciona o arrastra archivos.")
            return

        # Seleccionar carpeta de destino
        save_directory = filedialog.askdirectory()
        if save_directory:
            for file in self.file_paths:
                palabra_aleatoria = ()
                extension = file.split('.')[-1]  # Obtener la extensión del archivo original
                nuevo_nombre = f"{palabra_aleatoria}.{extension}"
                destino = f"{save_directory}/{nuevo_nombre}"
                
                # Verificar el tipo de archivo usando la biblioteca mimetypes
                mime_type, _ = mimetypes.guess_type(file)
                if mime_type:
                    main_type, sub_type = mime_type.split('/')
                    if main_type == 'image':
                        # Si es una imagen, usar Pillow para abrir y guardar
                        img = Image.open(file)
                        img.save(destino)
                    elif main_type == 'video':
                        # Si es un video, simplemente copiarlo sin modificar
                        shutil.copy(file, destino)
                    elif main_type == 'application' and sub_type == 'pdf':
                        # Si es un PDF, simplemente copiarlo sin modificar
                        shutil.copy(file, destino)
                    elif main_type == 'text':
                        # Si es un archivo de texto, simplemente copiarlo sin modificar
                        shutil.copy(file, destino)
                    else:
                        # Para cualquier otro tipo de archivo, simplemente copiarlo sin modificar
                        shutil.copy(file, destino)
                else:
                    # Si no se puede determinar el tipo de archivo, simplemente copiarlo sin modificar
                    shutil.copy(file, destino)
                
                print(f"Guardando {file} como {destino}")
            messagebox.showinfo("Descarga completa", f"Los archivos se han guardado en {save_directory}.")
        else:
            messagebox.showwarning("Sin selección", "No se ha seleccionado ninguna carpeta.")


    def ocultar_con_steghide(self, archivo, texto_secreto):
        """
        Esta función utiliza la herramienta Steghide para ocultar un texto secreto al final de un archivo.

        Args:
            archivo (str): La ruta al archivo al que se desea agregar el texto oculto.
            texto_secreto (str): El texto que se desea ocultar.

        Returns:
            bool: True si el proceso se realizó con éxito, False en caso contrario.
        """
        try:
            # Ejecutar el comando de Steghide para ocultar el texto en el archivo
            subprocess.run(["steghide", "embed", "-cf", archivo, "-ef", "-", "-p", "", "-Z", "-e", "none", "-N", "-t", "-f"], input=texto_secreto.encode(), check=True)
            return True
        except subprocess.CalledProcessError:
            print("Error: No se pudo ocultar el texto con Steghide.")
            return False

    # Agregar funciones para OutGuess, OpenStego, Steganography Tools e Invisible Secrets de manera similar...

    def ocultar_texto(self):
        if not self.file_paths:
            messagebox.showwarning("Sin archivos", "Primero selecciona o arrastra archivos.")
            return

        # Obtener el texto a ocultar
        texto_secreto = self.get_text_to_hide()

        # Seleccionar carpeta de destino
        save_directory = filedialog.askdirectory()
        if save_directory:
            for file in self.file_paths:
                palabra_aleatoria = self.bancopalabras()
                extension = file.split('.')[-1]  # Obtener la extensión del archivo original
                nuevo_nombre = f"{palabra_aleatoria}.{extension}"
                destino = f"{save_directory}/{nuevo_nombre}"
                
                # Verificar el tipo de archivo usando la biblioteca mimetypes
                mime_type, _ = mimetypes.guess_type(file)
                if mime_type:
                    main_type, sub_type = mime_type.split('/')
                    if main_type == 'image':
                        # Si es una imagen, usar Pillow para abrir y guardar
                        img = Image.open(file)
                        img.save(destino)
                    elif main_type == 'video':
                        # Si es un video, simplemente copiarlo sin modificar
                        shutil.copy(file, destino)
                    elif main_type == 'application' and sub_type == 'pdf':
                        # Si es un PDF, simplemente copiarlo sin modificar
                        shutil.copy(file, destino)
                    elif main_type == 'text':
                        # Si es un archivo de texto, simplemente copiarlo sin modificar
                        shutil.copy(file, destino)
                    else:
                        # Para cualquier otro tipo de archivo, simplemente copiarlo sin modificar
                        shutil.copy(file, destino)
                else:
                    # Si no se puede determinar el tipo de archivo, simplemente copiarlo sin modificar
                    shutil.copy(file, destino)
                
                print(f"Guardando {file} como {destino}")

                # Ocultar texto en el archivo
                if not self.ocultar_con_steghide(destino, texto_secreto):
                    messagebox.showerror("Error", f"No se pudo ocultar el texto en {destino}.")
                    return

            messagebox.showinfo("Descarga completa", f"Los archivos se han guardado en {save_directory}.")
        else:
            messagebox.showwarning("Sin selección", "No se ha seleccionado ninguna carpeta.")

def get_text_to_hide(self):
    # Crear ventana para ingresar el texto secreto
    text_window = tk.Toplevel(self.root)
    text_window.title("Texto Secreto")
    
    texto_label = tk.Label(text_window, text="Ingrese el texto secreto que desea ocultar:")
    texto_label.pack()
    
    texto_entry = tk.Entry(text_window)
    texto_entry.pack()
    
    confirm_button = tk.Button(text_window, text="Confirmar", command=text_window.destroy)
    confirm_button.pack()
    
    # Esperar hasta que se cierre la ventana de texto
    text_window.wait_window(text_window)
    
    return texto_entry.get()


if __name__ == "__main__":
    root = TkinterDnD.Tk()
    app = App(root)
    root.mainloop()

